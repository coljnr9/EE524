#pragma once
#include "CL/cl.h"


const char *getCLErrorString(cl_int err_var);